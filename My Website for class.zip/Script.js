document.getElementById("btn").addEventListener("click", Q1);

function Q1() {
    Answer = 0;
    let Question4 = document.getElementById("Q4Input").value;
    let Question3 = document.getElementById("Q3Input").value;
    let Question2 = document.getElementById("Q2Input").value;
    let Question1 = document.getElementById("Q1Input").value;

    if (Question1 === "Airfoil") {
        Answer++;
    } else if (Question1 === "") {
        document.getElementById("Q1suggest").innerHTML = ("incorrect, please write an answer.");
        document.getElementById("Q1suggest").style.color = ("grey");
    } else if (Question1 === "airfoil") {
        Answer++;
        document.getElementById("Q1suggest").innerHTML = ("Correct");
        document.getElementById("Q1suggest").style.color = ("green");
    } else if (Question1 !== "Airoil", "airfoil") {
        document.getElementById("Q1suggest").innerHTML = ("incorrect, check the bolded words on the about page");
        document.getElementById("Q1suggest").style.color = ("red");
    }


    if (Question2 === "Vent") {
        Answer++;
    } else if (Question2 === "") {
        document.getElementById("Q2suggest").innerHTML = ("incorrect, please write an answer.");
        document.getElementById("Q2suggest").style.color = ("grey");
    } else if (Question2 === "vent") {
        Answer++;
        document.getElementById("Q2suggest").innerHTML = ("Correct");
        document.getElementById("Q2suggest").style.color = ("green");
    } else if (Question2 !== "Vent", "vent") {
        document.getElementById("Q2suggest").innerHTML = ("incorrect, check the bolded words on the about page");
        document.getElementById("Q2suggest").style.color = ("red");
    }


    if (Question3 === "Flapping") {
        Answer++;
    } else if (Question3 === "") {
        document.getElementById("Q3suggest").innerHTML = ("incorrect, please write an answer.");
        document.getElementById("Q3suggest").style.color = ("grey");
    } else if (Question3 === "flapping") {
        Answer++;
        document.getElementById("Q3suggest").innerHTML = ("Correct");
        document.getElementById("Q3suggest").style.color = ("green");
    } else if (Question3 !== "Flapping", "flapping") {
        document.getElementById("Q3suggest").innerHTML = ("Incorrect, check the bolded words on the about page");
        document.getElementById("Q3suggest").style.color = ("red");
    }


    if (Question4 === "Bernoulli's principle") {
        Answer++;
        document.getElementById("Q4suggest").innerHTML = ("Correct");
        document.getElementById("Q4suggest").style.color = ("green");
    } else if (Question4 === "") {
        document.getElementById("Q4suggest").innerHTML = ("incorrect, please write an answer.");
        document.getElementById("Q4suggest").style.color = ("grey");
    } else if (Question4 === "Bernoulli") {
        Answer++;
        document.getElementById("Q4suggest").innerHTML = ("Correct");
        document.getElementById("Q4suggest").style.color = ("green");
    } else if (Question4 === "bernoulli") {
        Answer++;
        document.getElementById("Q4suggest").innerHTML = ("Correct");
        document.getElementById("Q4suggest").style.color = ("green");
    } else if (Question4 === "bernoulli's principle") {
        Answer++;
        document.getElementById("Q4suggest").innerHTML = ("Correct");
        document.getElementById("Q4suggest").style.color = ("green");
    } else if (Question4 !== "Bernoulli's principle", "bernoulli's principle", "Bernoulli", "bernoulli") {
        document.getElementById("Q4suggest").innerHTML = ("Incorrect, check the bolded words on the about page");
        document.getElementById("Q4suggest").style.color = ("red");
    }


    if (Answer === 4) {
        document.getElementById("percent").innerHTML = ("congratulations you go 100%!")
    } else if (Answer === 3) {
        document.getElementById("percent").innerHTML = ("oops you got 75%!")
    } else if (Answer === 2) {
        document.getElementById("percent").innerHTML = ("oops you got 50%!")
    } else if (Answer === 1) {
        document.getElementById("percent").innerHTML = ("oops you got 25%!")
    } else if (Answer === 0) {
        document.getElementById("percent").innerHTML = ("You failed, please try again!")
    }
}